const express = require('express');
const app = express();
const port = 3001;

const validCodes = {
  "OV-DROP1-06IG": "hoodie-drop1-white",
  "OV-DROP1-3QSA": "hoodie-drop1-white",
  "OV-DROP1-43EC": "hoodie-drop1-white",
  // ... voeg alle codes toe
};

app.get('/verifyBadge', (req, res) => {
  const code = req.query.code?.trim().toUpperCase();

  if (!code) {
    return res.status(400).json({ valid: false, message: "Code ontbreekt" });
  }

  if (validCodes[code]) {
    return res.json({
      valid: true,
      hoodieVariant: validCodes[code],
      message: "Code geldig ✅ toegang verleend",
    });
  } else {
    return res.json({
      valid: false,
      message: "Ongeldige code ❌ toegang geweigerd",
    });
  }
});

app.listen(port, () => {
  console.log(`✅ Server draait op http://localhost:${port}`);
});
